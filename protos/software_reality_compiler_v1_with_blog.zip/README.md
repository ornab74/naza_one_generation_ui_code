# Software Reality Compiler v1

This bundle is a drop-in first implementation for the existing Naza `lib/agentic` layer.

## Included

- `lib/agentic/software_reality_compiler.dart`
- `test/software_reality_compiler_test.dart`

## Concepts implemented as code

- software-state futures rather than a single immediate patch
- epistemic claims and evidence dependencies
- contradictory claims
- delayed collapse
- normalized state-field entropy
- information-gain experiment ranking
- capability-aware experiments
- critical software invariants
- reversible semantic transforms
- proof artifacts
- proof-carrying patch envelopes
- synthetic adversarial engineering organizations
- reasoner ancestry tracking to discount correlated consensus
- empirical agent trust profiles
- ephemeral tool-genesis requests

## Integration with the current Code Foundry

Use `NazaSoftwareRealityCompiler` above the existing model-routing layer:

1. Start a `NazaRealitySession` for a coding task.
2. Convert repository snapshots into `NazaRealityEvidence`.
3. Convert Local Gemma / remote / sharded outputs into `modelContribution` evidence.
4. Record a `NazaReasonerTrace` for each model result, including an ancestry/context digest.
5. Ask reasoners for explicit claims, invariants, experiments, semantic transforms and candidate futures.
6. Run `rankExperiments()` before spending more compute.
7. Feed test/static-analysis/runtime results back as evidence and proof artifacts.
8. Keep multiple futures alive until `collapse()` allows one.
9. Wrap the final diff with `issuePatch()` so it carries rollback, proofs, unresolved claims and a digest.
10. Keep the repo's existing per-run approvals around any later shell/container/SSH executor.

The kernel itself does not execute shell commands, network operations or mutations. That separation is intentional: inference proposes possible realities; host policy controls observation and collapse into action.

# Beyond Coding Agents: Building a Software Reality Compiler

Modern coding agents are usually variations of the same classical loop:

\[
\text{prompt} \rightarrow \text{inspect repository} \rightarrow \text{edit code} \rightarrow \text{run tests} \rightarrow \text{repeat}.
\]

That is useful, but architecturally narrow. It assumes one active interpretation of the software, one primary trajectory through the search space, and a relatively simple notion of confidence: if the model can produce a plausible patch and the tests pass, the process converges.

The new **Software Reality Compiler** changes that model.

Instead of treating code generation as a linear action loop, it represents software engineering as inference over a field of competing possible program states. Models are not authorities. A repository snapshot is not truth. Tests are not complete specifications. Agreement between several agents is not automatically independent evidence. A patch does not become actionable simply because it looks plausible.

The system therefore separates five different objects that ordinary coding agents tend to collapse together:

\[
\boxed{
\text{Intent}
\neq
\text{Belief}
\neq
\text{Evidence}
\neq
\text{Candidate Future}
\neq
\text{Executable Change}
}
\]

That separation is the core architectural change.

---

## 1. From a coding loop to a software state field

A conventional coding agent approximately operates on one state:

\[
S_t = (\text{repository at time } t).
\]

It proposes an action \(a_t\), obtains a new state, and continues:

\[
S_{t+1} = T(S_t,a_t).
\]

The new compiler instead maintains a set of candidate software futures:

\[
\mathcal{F} = \{F_1,F_2,\ldots,F_n\}.
\]

Each future is a possible coherent transformation of the software system. One future might be a minimal parser fix, another a boundary refactor, another a compatibility-preserving migration, and another a security-first redesign.

The compiler assigns each future a normalized weight:

\[
w_i =
\frac{\exp(s_i/\tau)}
{\sum_j \exp(s_j/\tau)}
\]

where:

- \(s_i\) is the heuristic support score of future \(F_i\),
- \(\tau\) is a temperature parameter controlling how aggressively weak alternatives are suppressed.

The implementation uses a deliberately non-zero temperature so plausible alternatives are not annihilated too early. This is **delayed collapse**.

The important design principle is:

> do not force the system to pretend uncertainty disappeared merely because one model spoke first.

---

# 2. Epistemic claims become first-class state

The existing Code Foundry already preserved provenance and model disagreement. The new layer goes further by representing beliefs explicitly.

A `NazaEpistemicClaim` contains:

- a proposition,
- a prior weight,
- supporting or opposing evidence,
- parent claims,
- contradictory claims,
- an impact score,
- a lifecycle state such as active, challenged, or invalidated.

For example:

> “The authorization defect is caused by the ownership check being missing at the canonical boundary.”

is no longer prose buried inside an LLM response. It becomes a node in the reasoning graph.

A simplified claim score is:

\[
C =
0.36P
+
0.44E
+
0.20D
-
0.55X
-
Q
\]

where:

- \(P\) = prior support,
- \(E\) = normalized evidence signal,
- \(D\) = parent/dependency support,
- \(X\) = strongest contradictory-claim support,
- \(Q\) = challenge penalty.

The final value is bounded:

\[
C \in [0,1].
\]

This is intentionally **not** called “probability of truth.” It is a deterministic review weight.

That distinction matters. A software agent should not magically convert heuristics into fake Bayesian certainty.

---

# 3. Evidence is separate from claims

A claim can be supported by many evidence objects:

\[
E = \{
E_{\text{repo}},
E_{\text{test}},
E_{\text{trace}},
E_{\text{benchmark}},
E_{\text{human}},
E_{\text{model}},
\ldots
\}
\]

The implementation supports evidence kinds including:

- repository observations,
- static analysis,
- tests,
- benchmarks,
- runtime traces,
- specification evidence,
- human observations,
- model contributions,
- external sources.

Each evidence object receives a digest:

\[
d(E)=\operatorname{SHA256}(\text{bounded evidence material})
\]

and a reliability weight:

\[
r(E)\in[0,1].
\]

A claim's evidence signal is formed from signed evidence weights:

\[
E_C =
\frac{\sum_i \alpha_i r_i}
{\sum_i r_i}
\]

where:

\[
\alpha_i \in [-1,1].
\]

Positive evidence supports a claim. Negative evidence opposes it.

This gives the system an explicit epistemic dependency graph instead of letting conclusions disappear into model prose.

---

# 4. Evidence invalidation propagates conceptually

The compiler tracks evidence independently so observations can later be invalidated.

Suppose a benchmark was performed with the wrong compiler flags.

A classical agent may have already built several conclusions on top of it.

In the new model, the benchmark evidence is a distinct node. Once invalidated, it stops contributing to the weight of claims that referenced it.

Conceptually:

\[
E_k \rightarrow C_2 \rightarrow C_9 \rightarrow F_3
\]

If \(E_k\) disappears, every downstream weight is recomputed.

This is dependency management for knowledge.

---

# 5. Candidate software futures replace immediate edits

The system adds `NazaSoftwareFuture`.

A future contains:

- a thesis,
- supporting claims,
- semantic transforms,
- protected invariants,
- scores across multiple time horizons,
- security score,
- reversibility score,
- complexity cost,
- base weight.

The raw future score is currently:

\[
s_i =
0.34C_i
+
0.18T_i
+
0.16I_i
+
0.14S_i
+
0.12R_i
+
0.06(1-K_i)
\]

where:

- \(C_i\) = claim support,
- \(T_i\) = temporal score,
- \(I_i\) = invariant coverage,
- \(S_i\) = security score,
- \(R_i\) = reversibility score,
- \(K_i\) = complexity cost.

This is not intended to be the final universal scoring function. The architectural point is more important:

> a patch is evaluated as one possible future of the software system, not merely as text that happens to satisfy a prompt.

---

# 6. Temporal reasoning is built into futures

Each future can be scored across several horizons:

\[
T =
\frac{
T_{\text{immediate}}
+
T_{\text{release}}
+
T_{\text{long-term}}
}{3}.
\]

This prevents an agent from optimizing only the next five minutes.

A tiny compatibility hack may score:

\[
T_{\text{immediate}} = 0.95
\]

but:

\[
T_{\text{long-term}} = 0.25.
\]

A somewhat larger architectural correction might have the reverse profile.

The compiler can therefore distinguish:

> “this fixes the immediate bug”

from:

> “this creates the better software trajectory.”

---

# 7. State-field entropy measures unresolved competition

Once candidate futures have normalized weights \(w_i\), the compiler calculates field entropy:

\[
H(\mathcal{F})
=
-\sum_i w_i \log_2 w_i.
\]

It is normalized by the maximum possible entropy:

\[
H_{\text{norm}}
=
\frac{H(\mathcal{F})}
{\log_2 n}.
\]

Therefore:

\[
H_{\text{norm}}\in[0,1].
\]

Interpretation:

- \(H \approx 0\): one future dominates.
- \(H \approx 1\): the field remains highly unresolved.

This is different from the earlier shard-disagreement metric.

The previous system measured disagreement between model outputs.

The new system measures uncertainty over **candidate software realities**.

That is a deeper abstraction.

---

# 8. Collapse is a policy boundary, not a model decision

The compiler only allows a future to collapse into an actionable patch if several constraints hold.

At minimum:

\[
w_{\text{winner}} \ge w_{\min}
\]

and:

\[
w_{\text{winner}}
-
w_{\text{runner-up}}
\ge \Delta_{\min}.
\]

The current defaults are approximately:

\[
w_{\min}=0.60
\]

and:

\[
\Delta_{\min}=0.16.
\]

But weight dominance alone is not enough.

The compiler can still block collapse when:

- high-impact claims remain uncertain,
- critical invariants lack proof,
- a semantic transform is irreversible,
- competing futures remain too close.

This produces a crucial inversion:

> the model does not decide when reasoning is finished.

The **host collapse policy** decides when enough independent evidence exists to justify turning possibility into action.

---

# 9. The system asks what it should learn next

The new `NazaExperiment` layer implements an **active ignorance engine**.

Instead of simply asking another model for another opinion, the compiler ranks potential experiments by expected information gain.

For a claim weight \(p\), binary uncertainty is represented as:

\[
H_b(p)
=
-p\log_2p
-(1-p)\log_2(1-p).
\]

This quantity peaks near:

\[
p=0.5
\]

and approaches zero near:

\[
p=0
\quad\text{or}\quad
p=1.
\]

For an experiment affecting several claims, the compiler combines uncertainty with impact:

\[
IG
=
\bar H_b
\left(
0.4+0.6\bar I
\right)
\]

where:

- \(\bar H_b\) = average uncertainty,
- \(\bar I\) = average claim impact.

Then the experiment priority incorporates cost:

\[
P_{\text{experiment}}
=
\frac{IG}{IG + C}.
\]

So the central reasoning question becomes:

> What observation would most efficiently destroy important uncertainty?

This is much stronger than:

> Which file should I read next?

---

# 10. Experiments are capability-aware

Experiments are classified by capability:

- read-only,
- mutation,
- network,
- remote execution.

The ranking engine only considers experiments permitted by the host policy.

That means a cheap remote-production probe cannot silently outrank a safe local trace when remote execution has not been approved.

This preserves the existing Code Foundry capability model while moving the reasoning layer far beyond a simple planner.

---

# 11. Critical software invariants must carry proof

The new compiler adds `NazaSoftwareInvariant`.

Examples:

- another user must never read this invoice,
- queued data must survive restart,
- a migration must preserve all canonical identifiers,
- an API response must remain backwards compatible,
- credentials must never enter telemetry.

A critical invariant blocks collapse unless it has a passing proof artifact.

Conceptually:

\[
\text{CriticalInvariant}(I)
\Rightarrow
\exists P:
\text{proves}(P,I)
\land
\text{passed}(P).
\]

Proof artifacts can represent:

- tests,
- property checks,
- static analysis,
- benchmarks,
- compatibility checks,
- threat analysis,
- rollback checks,
- runtime traces.

This changes the meaning of “done.”

A model saying:

> “This should be safe”

is irrelevant unless a proof-bearing observation supports the claim.

---

# 12. Proof artifacts are digest-bearing objects

A proof artifact is not just an English sentence.

It includes:

\[
\operatorname{digest}(P)
=
\operatorname{SHA256}(\text{proof material})
\]

along with:

- proof kind,
- summary,
- pass/fail state.

This allows the final patch to refer to concrete verification objects instead of unverifiable narrative.

---

# 13. Semantic transforms sit above textual diffs

The system introduces `NazaSemanticTransform`.

This distinguishes:

\[
\text{Meaning of change}
\]

from:

\[
\text{Serialized textual diff}.
\]

For example, the semantic transformation may be:

> “Move ownership validation to the canonical authorization boundary.”

Its final Dart diff is merely one representation of that transformation.

A transform records:

- intent,
- affected paths,
- protected invariants,
- inverse description,
- reversibility.

This moves toward a **semantic patch algebra**.

Longer term, transforms could be composed:

\[
T =
T_3 \circ T_2 \circ T_1
\]

or inverted:

\[
T^{-1}.
\]

The initial implementation establishes the typed representation required for that future work.

---

# 14. Reversibility is a first-class gate

The compiler rejects irreversible semantic transforms under the default collapse policy.

For a transform \(T\), the desirable property is:

\[
\exists T^{-1}
\]

such that:

\[
T^{-1}(T(S)) \approx S.
\]

Software reality is messy, so perfect mathematical reversibility is rarely possible. The implementation therefore requires an explicit inverse description and a boolean policy classification.

The principle is simple:

> before an autonomous system changes the world, it should know how the change can be unwound.

---

# 15. Final changes become proof-carrying patches

The final output is no longer just:

```diff
+ some code
```

The compiler produces a `NazaProofCarryingPatch` containing:

- selected future,
- unified diff,
- rollback plan,
- proof artifact IDs,
- unresolved claims,
- final digest,
- human-review requirement.

Conceptually:

\[
\Pi =
(
\Delta,
F,
P,
R,
U,
D
)
\]

where:

- \(\Delta\) = code diff,
- \(F\) = selected future,
- \(P\) = proof set,
- \(R\) = rollback plan,
- \(U\) = unresolved claims,
- \(D\) = integrity digest.

A code change without this surrounding evidence is treated as epistemically incomplete.

---

# 16. Correlated model agreement is discounted

Multi-agent systems often make a serious mistake:

three models say the same thing, therefore confidence rises three times.

But suppose all three were given the same misleading summary.

Their outputs are not independent observations.

The new compiler introduces `NazaReasonerTrace` with an `ancestryDigest`.

Independent-reasoner coverage is approximated as:

\[
R_{\text{ind}}
=
\frac{
|\{\text{unique ancestry digests}\}|
}{
|\{\text{reasoners}\}|
}.
\]

If two models share the same ancestry:

\[
R_{\text{ind}}=\frac{1}{2}.
\]

This does not fully solve correlation modeling, but it establishes the correct principle:

> count independent evidence, not model headcount.

---

# 17. Agent reliability becomes empirical

The system adds `NazaAgentTrustProfile`.

Instead of hard-coding:

```text
GPT trust = 0.78
Gemma trust = 1.0
```

the compiler can track whether previous claims survived later verification.

A simple smoothed reliability estimate is:

\[
R =
\frac{c+1}
{c+i+2}
\]

where:

- \(c\) = verified correct outcomes,
- \(i\) = verified incorrect outcomes.

This is a Beta-prior style estimate.

It means trust can eventually become:

- task-specific,
- evidence-based,
- dynamically calibrated.

A model that is excellent at Flutter layout but weak at cryptographic protocol reasoning should not receive one global trust constant.

---

# 18. Synthetic engineering organizations replace static agent roles

The system adds task-dependent synthetic organizations.

Every task starts with roles such as:

- Builder,
- Breaker,
- Verifier,
- Historian.

Then domain-specific roles are generated when the task surface demands them.

For security-related work:

- Security Adversary.

For database work:

- Data Guardian.

For Flutter/UI work:

- Interaction Critic.

This is deliberately adversarial.

The architecture does not optimize agent agreement. It creates organizational tension so weak assumptions are attacked before collapse.

That produces a very different topology from:

\[
\text{Planner}\rightarrow\text{Coder}\rightarrow\text{Reviewer}.
\]

Instead, the system becomes closer to:

\[
\{\text{Builder},\text{Breaker},\text{Verifier},\text{Historian},\ldots\}
\rightarrow
\text{shared evidence field}.
\]

Agents do not pass one final answer down a chain.

They modify a shared epistemic state.

---

# 19. Tool genesis: the system can propose new senses

The new compiler also introduces `NazaToolGenesisRequest`.

When high-impact claims remain uncertain, the system can conclude that the correct next step is not another model call.

It can propose an ephemeral tool such as:

- causal trace collector,
- schema comparator,
- compatibility probe,
- state-transition visualizer,
- fuzzing harness,
- migration simulator.

This changes the architecture from:

\[
\text{Agent} + \text{fixed tools}
\]

to:

\[
\text{Agentic field} + \text{tools synthesized from missing observations}.
\]

The initial implementation only proposes the tool requirement. A future execution layer can materialize it under explicit capability approval.

---

# 20. Why this is beyond Codex-style coding

A powerful Codex-style system can already:

- inspect code,
- edit files,
- run commands,
- test changes,
- iterate.

That remains valuable.

But the Software Reality Compiler introduces a different abstraction.

### Classical coding-agent model

\[
\text{Goal}
\rightarrow
\text{Agent}
\rightarrow
\text{Tool Calls}
\rightarrow
\text{Patch}
\]

### Software Reality Compiler model

\[
\text{Intent}
\rightarrow
\text{Epistemic Graph}
\rightarrow
\text{Competing Futures}
\rightarrow
\text{Active Experiments}
\rightarrow
\text{Proof + Invariants}
\rightarrow
\text{Collapse Policy}
\rightarrow
\text{Proof-Carrying Patch}
\]

The individual LLM becomes a component inside the inference fabric.

It is no longer the system itself.

---

# 21. How this connects to the existing Naza Code Foundry

The earlier agentic layer already has several strong properties:

- local-first Gemma synthesis,
- bounded repository evidence,
- secret filtering,
- remote model routing,
- sharded provider assembly,
- provenance,
- disagreement telemetry,
- explicit per-run permissions,
- planning-only execution boundary.

The new compiler should sit **above** that architecture.

A practical run becomes:

\[
\text{Repository Snapshot}
\rightarrow
E_{\text{repo}}
\]

\[
\text{Local Gemma Output}
\rightarrow
E_{\text{model-local}}
\]

\[
\text{Remote Shard Output}
\rightarrow
E_{\text{model-remote}}
\]

\[
\text{Static Analysis}
\rightarrow
E_{\text{static}}
\]

\[
\text{Test Result}
\rightarrow
E_{\text{test}}
\]

All of those observations enter one `NazaRealitySession`.

Then the compiler evaluates claims and futures.

---

# 22. Recommended integration pipeline

The resulting Code Foundry architecture becomes:

```text
USER INTENT
    |
    v
BOUNDED REPOSITORY OBSERVATION
    |
    v
REALITY SESSION
    |
    +--> EPISTEMIC CLAIM GRAPH
    |
    +--> SYNTHETIC ENGINEERING ORG
    |
    +--> LOCAL / REMOTE / SHARDED REASONERS
    |        |
    |        v
    |     MODEL EVIDENCE
    |
    +--> CANDIDATE SOFTWARE FUTURES
    |
    +--> INFORMATION-GAIN EXPERIMENTS
    |
    +--> TEST / TRACE / STATIC EVIDENCE
    |
    +--> INVARIANT PROOFS
    |
    v
STATE-FIELD EVALUATION
    |
    +--> high entropy --> gather more evidence
    |
    +--> low entropy but missing proof --> verify
    |
    +--> irreversible transform --> block
    |
    v
COLLAPSE BOUNDARY
    |
    v
PROOF-CARRYING PATCH
    |
    v
HUMAN / HOST EXECUTION POLICY
```

This preserves the strong safety properties of the existing implementation while greatly increasing the sophistication of its reasoning model.

---

# 23. What is deliberately not implemented yet

The current package is a **reasoning kernel**, not an autonomous executor.

It does not directly:

- run shell commands,
- edit the filesystem,
- SSH to machines,
- execute containers,
- deploy software,
- mutate production.

That separation is intentional.

The earlier Code Foundry correctly established that model-proposed actions should not silently become host actions.

The next stage should therefore connect experiments to host tool adapters while preserving:

\[
\text{Inference Permission}
\neq
\text{Execution Permission}.
\]

The field can decide:

> “A runtime trace would maximally reduce uncertainty.”

But the host still decides whether that action is authorized.

---

# 24. Deeper mathematical direction

The current future scoring is deterministic and heuristic. A much more advanced version could formalize the state field as:

\[
P(F_i \mid E)
\]

and update futures with sequential evidence:

\[
P(F_i\mid E_{1:t})
\propto
P(E_t\mid F_i)
P(F_i\mid E_{1:t-1}).
\]

Experiments could then maximize expected posterior entropy reduction:

\[
a^*
=
\arg\max_a
\left[
H(F\mid E)
-
\mathbb{E}_{o\sim a}
H(F\mid E,o)
\right].
\]

That is a genuine active-inference formulation.

Likewise, causal hypotheses could be represented using structural equations:

\[
X_j = f_j(\operatorname{Pa}(X_j),U_j)
\]

and debugging could compare interventions:

\[
P(Y\mid do(X=x)).
\]

This would turn “try changing this function” into:

> perform the intervention that most strongly discriminates between causal models.

---

# 25. Toward non-local software cognition

The term “non-local” is useful here in an architectural sense.

A software change rarely exists independently.

A schema edit can be correlated with:

- backend behavior,
- generated clients,
- cached mobile versions,
- analytics,
- migrations,
- authorization,
- observability,
- long-term product semantics.

So the compiler should eventually maintain explicit cross-layer coupling:

\[
C(A,B)\in[0,1]
\]

where \(C(A,B)\) represents how strongly two software regions constrain each other.

Then changing node \(A\) should immediately update the relevance field around \(B\), even if the files are far apart in the repository tree.

The filesystem is local.

Software meaning is not.

---

# 26. The fundamental architectural shift

The biggest change is not one class or equation.

It is the system's ontology.

Before:

> the software is the current repository, and the agent's job is to modify it.

After:

> the software is a partially observed computational world with competing interpretations and futures.

That gives us a new pipeline:

\[
\boxed{
\text{Intent}
\rightarrow
\text{Observation}
\rightarrow
\text{Hypotheses}
\rightarrow
\text{Possible Futures}
\rightarrow
\text{Discriminating Experiments}
\rightarrow
\text{Proof}
\rightarrow
\text{Collapse}
\rightarrow
\text{Reversible Change}
}
\]

The coding model becomes one observer among many.

The patch becomes the final collapsed artifact of a larger reasoning process.

And the real product is no longer an AI programmer.

It is a **compiler from uncertain software intent into evidence-backed computational reality**.

---

# Files added in this package

## `lib/agentic/software_reality_compiler.dart`

Adds the typed reasoning kernel:

- `NazaRealityEvidence`
- `NazaEpistemicClaim`
- `NazaSoftwareInvariant`
- `NazaSemanticTransform`
- `NazaSoftwareFuture`
- `NazaExperiment`
- `NazaReasonerTrace`
- `NazaAgentTrustProfile`
- `NazaProofArtifact`
- `NazaAgentRole`
- `NazaSyntheticOrganization`
- `NazaToolGenesisRequest`
- `NazaRealitySession`
- `NazaSoftwareRealityCompiler`
- `NazaCollapseDecision`
- `NazaProofCarryingPatch`

## `test/software_reality_compiler_test.dart`

Adds verification for:

- delayed collapse when futures remain degenerate,
- information-gain experiment ranking,
- capability filtering,
- critical invariant proof requirements,
- proof-carrying patch construction,
- correlated reasoner discounting,
- task-specific synthetic organizations.

---

# Final perspective

The old agentic-coding question is:

> What code should the model write?

The new question is:

> What software reality is best supported by the currently available evidence, what remains uncertain, what observation would reduce that uncertainty fastest, what invariants must survive, and when is it rational and reversible to collapse one future into code?

That is a substantially different machine.

import 'dart:async';

import 'package:flutter/material.dart';

import '../controller.dart';
import '../models.dart';
import '../widgets/glass.dart';

class NazaShell extends StatelessWidget {
  const NazaShell({super.key, required this.controller});
  final NazaController controller;

  static const _menuSections = <NazaSection>[
    NazaSection.modelManager,
    NazaSection.settings,
    NazaSection.roadScanner,
    NazaSection.defenseLab,
    NazaSection.scanHistory,
    NazaSection.rekey,
    NazaSection.exit,
  ];

  static const _icons = <NazaSection, IconData>{
    NazaSection.mainMenu: Icons.grid_view_rounded,
    NazaSection.modelManager: Icons.memory_rounded,
    NazaSection.settings: Icons.tune_rounded,
    NazaSection.roadScanner: Icons.route_rounded,
    NazaSection.defenseLab: Icons.shield_moon_rounded,
    NazaSection.scanHistory: Icons.history_rounded,
    NazaSection.rekey: Icons.key_rounded,
    NazaSection.exit: Icons.logout_rounded,
  };

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(-0.8, -0.9),
          radius: 1.45,
          colors: [
            Color(0xFF33235F),
            Color(0xFF15162A),
            Color(0xFF090A12),
          ],
          stops: [0, 0.48, 1],
        ),
      ),
      child: AnimatedBuilder(
        animation: controller,
        builder: (context, _) {
          return Scaffold(
            backgroundColor: Colors.transparent,
            body: SafeArea(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final desktop = constraints.maxWidth >= 980;
                  return Row(
                    children: [
                      if (desktop) _Sidebar(controller: controller, icons: _icons, sections: _menuSections),
                      Expanded(
                        child: Column(
                          children: [
                            _TopBar(controller: controller, showMenu: !desktop),
                            if (controller.busy)
                              LinearProgressIndicator(
                                value: controller.progress.clamp(0.0, 1.0).toDouble(),
                                minHeight: 2,
                              ),
                            Expanded(
                              child: Padding(
                                padding: EdgeInsets.fromLTRB(desktop ? 28 : 10, desktop ? 14 : 8, desktop ? 28 : 10, desktop ? 22 : 12),
                                child: RepaintBoundary(
                                  child: _ScreenRouter(
                                    controller: controller,
                                    menuSections: _menuSections,
                                    icons: _icons,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          );
        },
      ),
    );
  }
}

class _Sidebar extends StatelessWidget {
  const _Sidebar({required this.controller, required this.icons, required this.sections});
  final NazaController controller;
  final Map<NazaSection, IconData> icons;
  final List<NazaSection> sections;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 284,
      margin: const EdgeInsets.all(16),
      child: GlassPanel(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 18),
        child: Column(
          children: [
            InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () => unawaited(controller.navigate(NazaSection.mainMenu)),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Row(
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        gradient: const LinearGradient(colors: [Color(0xFF795CFF), Color(0xFF41D8FF), Color(0xFFE056B4)]),
                      ),
                      child: const Icon(Icons.hub_rounded, color: Colors.white),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('NAZA', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                          Text('LlamaDart Road Scanner', style: TextStyle(color: Colors.white54, fontSize: 12)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            Expanded(
              child: ListView.separated(
                itemCount: sections.length,
                separatorBuilder: (_, __) => const SizedBox(height: 5),
                itemBuilder: (context, index) {
                  final section = sections[index];
                  final active = controller.section == section;
                  return Material(
                    color: active ? Colors.white.withValues(alpha: 0.09) : Colors.transparent,
                    borderRadius: BorderRadius.circular(16),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () => section == NazaSection.exit
                          ? unawaited(controller.exitApp())
                          : unawaited(controller.navigate(section)),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                        child: Row(
                          children: [
                            GradientIcon(icons[section]!, size: 20),
                            const SizedBox(width: 11),
                            Expanded(
                              child: Text(
                                section.label,
                                style: TextStyle(
                                  color: active ? Colors.white : Colors.white70,
                                  fontWeight: active ? FontWeight.w700 : FontWeight.w500,
                                ),
                              ),
                            ),
                            if (active) const Icon(Icons.chevron_right_rounded, size: 18, color: Colors.white60),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            StatusPill(label: controller.status, icon: controller.busy ? Icons.sync_rounded : Icons.lock_rounded),
          ],
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({required this.controller, required this.showMenu});
  final NazaController controller;
  final bool showMenu;

  @override
  Widget build(BuildContext context) {
    if (showMenu) {
      // Mobile: no status-wall across the top. It was consuming two rows,
      // clipping the home button, and causing layout churn while status text
      // changed. Keep navigation stable and move status into the active page.
      return Padding(
        padding: const EdgeInsets.fromLTRB(8, 6, 8, 2),
        child: SizedBox(
          height: 48,
          child: Row(
            children: [
              IconButton(
                tooltip: 'Menu',
                onPressed: () => _showMobileMenu(context, controller),
                icon: const Icon(Icons.menu_rounded),
              ),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  controller.section.label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w800,
                      ),
                ),
              ),
              const SizedBox(width: 4),
              IconButton(
                tooltip: 'Main Menu',
                onPressed: () => unawaited(
                  controller.navigate(NazaSection.mainMenu),
                ),
                icon: const Icon(Icons.home_rounded),
              ),
            ],
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 4),
      child: Row(
        children: [
          Expanded(
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                StatusPill(
                  label: controller.loadedModelId == null
                      ? 'Model: none'
                      : 'Model: loaded',
                  icon: Icons.memory_rounded,
                ),
                StatusPill(label: 'Model: ${controller.selectedModel.name}'),
                StatusPill(
                  label: 'Defense: ${controller.settings.defenseProfile}',
                ),
                const StatusPill(label: 'Crypto: AES-256-GCM'),
                StatusPill(label: 'Backend: ${controller.runtimeBackend}'),
              ],
            ),
          ),
          IconButton(
            tooltip: 'Main Menu',
            onPressed: () => unawaited(
              controller.navigate(NazaSection.mainMenu),
            ),
            icon: const Icon(Icons.home_rounded),
          ),
        ],
      ),
    );
  }

  void _showMobileMenu(BuildContext context, NazaController controller) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF151521),
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.all(12),
          children: [
            for (final section in NazaShell._menuSections)
              ListTile(
                leading: GradientIcon(NazaShell._icons[section]!),
                title: Text(section.label),
                onTap: () {
                  Navigator.pop(context);
                  section == NazaSection.exit
                      ? unawaited(controller.exitApp())
                      : unawaited(controller.navigate(section));
                },
              ),
          ],
        ),
      ),
    );
  }
}

class _ScreenRouter extends StatelessWidget {
  const _ScreenRouter({required this.controller, required this.menuSections, required this.icons});
  final NazaController controller;
  final List<NazaSection> menuSections;
  final Map<NazaSection, IconData> icons;

  @override
  Widget build(BuildContext context) {
    return switch (controller.section) {
      NazaSection.mainMenu => _MainMenuPage(controller: controller, menuSections: menuSections, icons: icons),
      NazaSection.modelManager => _ModelManagerPage(controller: controller),
      NazaSection.settings => _SettingsPage(controller: controller),
      NazaSection.roadScanner => _RoadScannerPage(controller: controller),
      NazaSection.defenseLab => _DefenseLabPage(controller: controller),
      NazaSection.scanHistory => _ScanHistoryPage(controller: controller),
      NazaSection.rekey => _RekeyPage(controller: controller),
      NazaSection.exit => _MainMenuPage(controller: controller, menuSections: menuSections, icons: icons),
    };
  }
}

class _MainMenuPage extends StatelessWidget {
  const _MainMenuPage({required this.controller, required this.menuSections, required this.icons});
  final NazaController controller;
  final List<NazaSection> menuSections;
  final Map<NazaSection, IconData> icons;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionTitle(title: 'Main Menu', subtitle: 'Choose a mode and keep moving.'),
        const SizedBox(height: 20),
        Expanded(
          child: GridView.builder(
            gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 330,
              mainAxisExtent: 150,
              crossAxisSpacing: 14,
              mainAxisSpacing: 14,
            ),
            itemCount: menuSections.length,
            itemBuilder: (context, index) {
              final section = menuSections[index];
              return _MenuCard(
                label: section.label,
                icon: icons[section]!,
                onTap: () => section == NazaSection.exit
                    ? unawaited(controller.exitApp())
                    : unawaited(controller.navigate(section)),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _MenuCard extends StatelessWidget {
  const _MenuCard({required this.label, required this.icon, required this.onTap});
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      padding: EdgeInsets.zero,
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              GradientIcon(icon, size: 30),
              Row(
                children: [
                  Expanded(child: Text(label, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700))),
                  const Icon(Icons.arrow_forward_rounded, color: Colors.white54),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ModelManagerPage extends StatelessWidget {
  const _ModelManagerPage({required this.controller});
  final NazaController controller;

  static const actions = <String>[
    'Secure multi-host download / repair Llama 3 Small',
    'Configure Pinata / IPFS mirror',
    'Verify plaintext model SHA-256',
    'Encrypt plaintext model -> .aes',
    'Decrypt .aes -> plaintext (temporary)',
    'Delete plaintext model',
    'Back',
  ];

  @override
  Widget build(BuildContext context) {
    final compact = MediaQuery.sizeOf(context).width < 700;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionTitle(
          title: 'Model Manager',
          subtitle:
              'Verified multi-provider download, resumable chunks, and encrypted storage.',
        ),
        SizedBox(height: compact ? 10 : 16),
        GlassPanel(
          padding: EdgeInsets.all(compact ? 14 : 18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  StatusPill(label: 'Model: ${controller.selectedModel.name}'),
                  const StatusPill(label: 'GitHub: active'),
                  const StatusPill(label: 'Hugging Face: active'),
                  StatusPill(
                    label: controller.pinataModelUrl.isEmpty
                        ? 'Pinata: add mirror'
                        : 'Pinata: active',
                  ),
                  const StatusPill(label: 'SHA-256 pinned'),
                  const StatusPill(label: 'AES-256-GCM at rest'),
                ],
              ),
              if (controller.busy) ...[
                const SizedBox(height: 12),
                LinearProgressIndicator(
                  value: controller.progress.clamp(0.0, 1.0).toDouble(),
                  minHeight: 7,
                  borderRadius: BorderRadius.circular(99),
                ),
                const SizedBox(height: 8),
                Text(
                  controller.status,
                  maxLines: compact ? 3 : 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(color: Colors.white70),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: ListView.separated(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            itemCount: actions.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) => GlassPanel(
              padding: EdgeInsets.zero,
              radius: compact ? 16 : 18,
              child: ListTile(
                dense: compact,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: compact ? 12 : 16,
                  vertical: compact ? 2 : 5,
                ),
                leading: GradientIcon(_modelActionIcon(index)),
                title: Text(actions[index]),
                subtitle: index == 1 && controller.pinataModelUrl.isNotEmpty
                    ? Text(
                        controller.pinataModelUrl,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      )
                    : null,
                trailing: const Icon(
                  Icons.chevron_right_rounded,
                  color: Colors.white38,
                ),
                enabled: !controller.busy,
                onTap: () => _handle(context, index),
              ),
            ),
          ),
        ),
      ],
    );
  }

  IconData _modelActionIcon(int index) => const [
        Icons.downloading_rounded,
        Icons.hub_rounded,
        Icons.verified_rounded,
        Icons.lock_rounded,
        Icons.lock_open_rounded,
        Icons.delete_outline_rounded,
        Icons.arrow_back_rounded,
      ][index];

  Future<void> _handle(BuildContext context, int index) async {
    try {
      switch (index) {
        case 0:
          await controller.downloadActiveModel();
          break;
        case 1:
          await _configurePinataMirror(context);
          break;
        case 2:
          final result = await controller.verifyActiveModel();
          if (context.mounted) {
            await _message(context, 'SHA256 verification', result);
          }
          break;
        case 3:
          await controller.encryptActiveModel();
          break;
        case 4:
          await controller.decryptActiveModel();
          break;
        case 5:
          if (await _confirm(
            context,
            'Delete plaintext model?',
            'The encrypted .aes copy will be kept.',
          )) {
            await controller.deleteActivePlaintext();
          }
          break;
        case 6:
          await controller.navigate(NazaSection.mainMenu);
          break;
      }
    } catch (e) {
      if (context.mounted) await _message(context, 'Model Manager', '$e');
    }
  }

  Future<void> _configurePinataMirror(BuildContext context) async {
    final field = TextEditingController(text: controller.pinataModelUrl);
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Pinata / IPFS model mirror'),
        content: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 520),
          child: TextField(
            controller: field,
            autofocus: true,
            minLines: 2,
            maxLines: 4,
            keyboardType: TextInputType.url,
            decoration: const InputDecoration(
              hintText:
                  'https://your-gateway.mypinata.cloud/ipfs/CID\nor ipfs://CID',
              helperText:
                  'HTTPS Pinata gateways only. Leave blank to reset the built-in third mirror.',
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, field.text.trim()),
            child: const Text('Save mirror'),
          ),
        ],
      ),
    );
    field.dispose();
    if (value == null) return;
    await controller.setPinataModelUrl(value);
  }
}

class _SettingsPage extends StatelessWidget {
  const _SettingsPage({required this.controller});
  final NazaController controller;

  @override
  Widget build(BuildContext context) {
    final s = controller.settings;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionTitle(title: 'Settings', subtitle: 'Defense controls and colorwheel settings for the road scanner.'),
        const SizedBox(height: 14),
        Expanded(
          child: ListView(
            children: [
              _settingGroup(
                context,
                'Defense profile',
                DropdownButtonFormField<String>(
                  value: s.defenseProfile,
                  items: SecuritySettings.presets.keys
                      .map((name) => DropdownMenuItem(value: name, child: Text(name[0].toUpperCase() + name.substring(1))))
                      .toList(),
                  onChanged: (name) {
                    if (name != null) unawaited(controller.updateSettings(s.applyPreset(name)));
                  },
                ),
              ),
              _switchSetting('Toggle defense voting', s.defenseVoting, (v) => controller.updateSettings(s.copyWith(defenseVoting: v))),
              _switchSetting('Toggle colorwheel entropy', s.colorwheelEnabled, (v) => controller.updateSettings(s.copyWith(colorwheelEnabled: v))),
              _switchSetting('Toggle ML trace scramble', s.mlTraceScramble, (v) => controller.updateSettings(s.copyWith(mlTraceScramble: v))),
              _sliderSetting('Set colorwheel spins', s.colorwheelSpins.toDouble(), 16, 256, 240, (v) => controller.updateSettings(s.copyWith(colorwheelSpins: v.round()))),
              _sliderSetting('Set colorwheel rings', s.colorwheelRings.toDouble(), 6, 24, 18, (v) => controller.updateSettings(s.copyWith(colorwheelRings: v.round()))),
              _sliderSetting('Set max defense passes', s.maxDefensePasses.toDouble(), 1, 5, 4, (v) => controller.updateSettings(s.copyWith(maxDefensePasses: v.round()))),
              _sliderSetting('Set metric samples', s.metricSamples.toDouble(), 3, 13, 10, (v) => controller.updateSettings(s.copyWith(metricSamples: v.round()))),
              _sliderSetting('Set noise width', s.noiseWidth.toDouble(), 1, 4, 3, (v) => controller.updateSettings(s.copyWith(noiseWidth: v.round()))),
              _actionSetting('Run colorwheel spin test', Icons.color_lens_rounded, () async {
                final marker = controller.runColorwheelTest();
                await _message(context, 'Colorwheel spin test', marker);
              }),
              _actionSetting('Reset settings', Icons.restart_alt_rounded, () async {
                if (await _confirm(context, 'Reset settings?', 'Restore the hardened defaults?')) await controller.resetSettings();
              }),
              _actionSetting('Back', Icons.arrow_back_rounded, () => controller.navigate(NazaSection.mainMenu)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _settingGroup(BuildContext context, String label, Widget child) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: GlassPanel(
          radius: 18,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              child,
            ],
          ),
        ),
      );

  Widget _switchSetting(String label, bool value, Future<void> Function(bool) onChanged) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: GlassPanel(
          radius: 18,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
          child: SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(label),
            value: value,
            onChanged: (v) => unawaited(onChanged(v)),
          ),
        ),
      );

  Widget _sliderSetting(String label, double value, double min, double max, int divisions, Future<void> Function(double) onChanged) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: GlassPanel(
          radius: 18,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [Expanded(child: Text(label)), Text(value.round().toString(), style: const TextStyle(fontWeight: FontWeight.w700))]),
              Slider(value: value, min: min, max: max, divisions: divisions, onChanged: (v) => unawaited(onChanged(v))),
            ],
          ),
        ),
      );

  Widget _actionSetting(String label, IconData icon, Future<void> Function() onTap) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: GlassPanel(
          padding: EdgeInsets.zero,
          radius: 18,
          child: ListTile(
            leading: GradientIcon(icon),
            title: Text(label),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => unawaited(onTap()),
          ),
        ),
      );
}

class _RoadScannerPage extends StatefulWidget {
  const _RoadScannerPage({required this.controller});
  final NazaController controller;

  @override
  State<_RoadScannerPage> createState() => _RoadScannerPageState();
}

class _RoadScannerPageState extends State<_RoadScannerPage> {
  final location = TextEditingController();
  int mode = 1;

  @override
  void dispose() {
    location.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final result = widget.controller.roadResult;
    if (result != null) return _resultView(context, result);
    final compact = MediaQuery.sizeOf(context).width < 700;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionTitle(
          title: 'Road Scanner',
          subtitle: 'Capture a road location and classify risk.',
        ),
        SizedBox(height: compact ? 10 : 16),
        Expanded(
          child: ListView(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            children: [
              GlassPanel(
                padding: EdgeInsets.all(compact ? 14 : 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const GradientIcon(Icons.route_rounded, size: 24),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            'Road classification generation',
                            style: Theme.of(context)
                                .textTheme
                                .titleMedium
                                ?.copyWith(fontWeight: FontWeight.w800),
                          ),
                        ),
                        StatusPill(label: mode == 1 ? 'PUNKD + CHUNKD' : mode == 2 ? 'CHUNKD' : 'Direct'),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: location,
                      textInputAction: TextInputAction.done,
                      onSubmitted: (_) => _runScan(),
                      decoration: const InputDecoration(
                        labelText: 'Location',
                        hintText: 'Optional — leave blank for default context',
                        prefixIcon: Icon(Icons.location_on_outlined),
                      ),
                    ),
                    const SizedBox(height: 10),
                    RadioListTile<int>(
                      dense: compact,
                      contentPadding: EdgeInsets.zero,
                      value: 1,
                      groupValue: mode,
                      title: const Text('1) Chunked generation + punkd (recommended)'),
                      onChanged: widget.controller.busy ? null : (v) => setState(() => mode = v!),
                    ),
                    RadioListTile<int>(
                      dense: compact,
                      contentPadding: EdgeInsets.zero,
                      value: 2,
                      groupValue: mode,
                      title: const Text('2) Chunked only'),
                      onChanged: widget.controller.busy ? null : (v) => setState(() => mode = v!),
                    ),
                    RadioListTile<int>(
                      dense: compact,
                      contentPadding: EdgeInsets.zero,
                      value: 3,
                      groupValue: mode,
                      title: const Text('3) Direct single-call generation'),
                      onChanged: widget.controller.busy ? null : (v) => setState(() => mode = v!),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              if (widget.controller.busy)
                GlassPanel(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      LinearProgressIndicator(
                        value: widget.controller.progress.clamp(0.0, 1.0).toDouble(),
                        minHeight: 7,
                        borderRadius: BorderRadius.circular(99),
                      ),
                      const SizedBox(height: 9),
                      Text(
                        widget.controller.status,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context)
                            .textTheme
                            .bodySmall
                            ?.copyWith(color: Colors.white70),
                      ),
                    ],
                  ),
                )
              else
                FilledButton.icon(
                  onPressed: _runScan,
                  icon: const Icon(Icons.radar_rounded),
                  label: Padding(
                    padding: EdgeInsets.symmetric(vertical: compact ? 12 : 14),
                    child: Text(mode == 1 ? 'Scan with PUNKD + CHUNKD' : mode == 2 ? 'Scan with CHUNKD' : 'Scan direct'),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  void _runScan() {
    if (widget.controller.busy) return;
    FocusManager.instance.primaryFocus?.unfocus();
    unawaited(widget.controller.runRoadScan(location.text, mode));
  }

  Widget _resultView(BuildContext context, RoadScanResult result) {
    final compact = MediaQuery.sizeOf(context).width < 700;
    final detailStyle = Theme.of(context).textTheme.bodyMedium?.copyWith(
          color: Colors.white.withValues(alpha: 0.82),
          height: 1.35,
        );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionTitle(
          title: 'Road Scanner Result',
          subtitle: 'Classification, defense votes, and encrypted result actions.',
        ),
        SizedBox(height: compact ? 10 : 14),
        Expanded(
          child: ListView(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            children: [
              GlassPanel(
                padding: EdgeInsets.all(compact ? 14 : 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Text(
                            result.classification,
                            style: TextStyle(
                              fontSize: compact ? 38 : 46,
                              height: 1,
                              fontWeight: FontWeight.w900,
                              color: _riskColor(result.classification),
                            ),
                          ),
                        ),
                        StatusPill(label: result.generator),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        StatusPill(label: 'Votes: ${result.votes.join(', ')}'),
                        StatusPill(label: 'Model: ${result.model}'),
                        StatusPill(label: result.multiNode),
                      ],
                    ),
                    const SizedBox(height: 14),
                    _ResultDetail(
                      label: 'Colorwheel',
                      value: result.colorwheel,
                      style: detailStyle,
                    ),
                    const SizedBox(height: 9),
                    _ResultDetail(
                      label: 'Defense',
                      value: result.defenseCapsule,
                      style: detailStyle,
                    ),
                    const SizedBox(height: 9),
                    _ResultDetail(
                      label: 'Model output',
                      value: result.generatedOutput,
                      style: detailStyle,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              GlassPanel(
                padding: EdgeInsets.all(compact ? 12 : 18),
                child: compact
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: _resultActions(context),
                      )
                    : Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        alignment: WrapAlignment.end,
                        children: _resultActions(context),
                      ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  List<Widget> _resultActions(BuildContext context) => [
        OutlinedButton.icon(
          onPressed: () => widget.controller.cancelRoadScan(),
          icon: const Icon(Icons.edit_rounded),
          label: const Text('Re-run with edits'),
        ),
        OutlinedButton.icon(
          onPressed: () async {
            try {
              final path = await widget.controller.exportRoadScan();
              if (context.mounted) {
                await _message(context, 'Export to JSON', path);
              }
            } catch (e) {
              if (context.mounted) {
                await _message(context, 'Export to JSON', '$e');
              }
            }
          },
          icon: const Icon(Icons.save_alt_rounded),
          label: const Text('Export JSON'),
        ),
        FilledButton.icon(
          onPressed: () => unawaited(widget.controller.saveRoadScanAndReturn()),
          icon: const Icon(Icons.check_rounded),
          label: const Text('Save & return'),
        ),
        TextButton(
          onPressed: () => unawaited(
            widget.controller.navigate(NazaSection.mainMenu),
          ),
          child: const Text('Cancel'),
        ),
      ];

  Color _riskColor(String label) => switch (label) {
        'High' => const Color(0xFFFF6B7A),
        'Low' => const Color(0xFF68E0B2),
        _ => const Color(0xFFFFC863),
      };
}

class _ResultDetail extends StatelessWidget {
  const _ResultDetail({
    required this.label,
    required this.value,
    required this.style,
  });

  final String label;
  final String value;
  final TextStyle? style;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.labelMedium?.copyWith(
                color: Colors.white54,
                fontWeight: FontWeight.w700,
              ),
        ),
        const SizedBox(height: 3),
        SelectableText(
          value,
          style: style,
        ),
      ],
    );
  }
}

class _DefenseLabPage extends StatelessWidget {
  const _DefenseLabPage({required this.controller});
  final NazaController controller;

  @override
  Widget build(BuildContext context) {
    final snapshot = controller.defenseSnapshot ?? controller.refreshDefenseLab();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Expanded(child: SectionTitle(title: 'Side-channel Defense Lab', subtitle: 'Local anomaly, colorwheel, and defense-pass diagnostics.')),
            IconButton(onPressed: controller.refreshDefenseLab, tooltip: 'Refresh', icon: const Icon(Icons.refresh_rounded)),
          ],
        ),
        const SizedBox(height: 14),
        Expanded(
          child: ListView(
            children: [
              GlassPanel(child: SelectableText('${snapshot.capsule}\n${snapshot.colorwheel}\nlocal_interference=${snapshot.interference.toStringAsFixed(2)}\nmulti_node=${snapshot.multiNode.toStringAsFixed(2)}')),
              const SizedBox(height: 12),
              GlassPanel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Vector scores', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
                    const SizedBox(height: 10),
                    for (final entry in snapshot.vectorScores.entries) ...[
                      Row(children: [Expanded(child: Text(entry.key)), Text(entry.value.toStringAsFixed(2))]),
                      LinearProgressIndicator(value: entry.value, minHeight: 6, borderRadius: BorderRadius.circular(99)),
                      const SizedBox(height: 10),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 12),
              GlassPanel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Recommendations', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
                    const SizedBox(height: 10),
                    for (final rec in snapshot.recommendations) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text('• $rec')),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _ScanHistoryPage extends StatefulWidget {
  const _ScanHistoryPage({required this.controller});
  final NazaController controller;

  @override
  State<_ScanHistoryPage> createState() => _ScanHistoryPageState();
}

class _ScanHistoryPageState extends State<_ScanHistoryPage> {
  final search = TextEditingController();

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionTitle(title: 'Scan History', subtitle: 'Encrypted road-scan records with paging and search.'),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: search,
                decoration: const InputDecoration(hintText: 'Enter search keyword (empty to clear)'),
                onSubmitted: (value) => unawaited(c.setScanHistorySearch(value)),
              ),
            ),
            const SizedBox(width: 8),
            IconButton(onPressed: () => unawaited(c.setScanHistorySearch(search.text)), icon: const Icon(Icons.search_rounded)),
          ],
        ),
        const SizedBox(height: 10),
        Expanded(
          child: c.scanHistory.isEmpty
              ? const Center(child: Text('No rows on this page.', style: TextStyle(color: Colors.white54)))
              : ListView.separated(
                  itemCount: c.scanHistory.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 9),
                  itemBuilder: (context, index) {
                    final row = c.scanHistory[index];
                    return GlassPanel(
                      radius: 18,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('[${row.id}] ${row.timestamp}', style: const TextStyle(color: Colors.white54, fontSize: 12)),
                          const SizedBox(height: 8),
                          SelectableText('Location: ${row.location}\nClassification: ${row.classification}\nModel: ${row.model}\nGenerator: ${row.generator}'),
                        ],
                      ),
                    );
                  },
                ),
        ),
        const SizedBox(height: 10),
        GlassPanel(
          padding: const EdgeInsets.all(10),
          radius: 18,
          child: Row(
            children: [
              OutlinedButton.icon(onPressed: c.scanHistoryPage > 0 ? () => unawaited(c.scanHistoryPrevious()) : null, icon: const Icon(Icons.chevron_left_rounded), label: const Text('Previous page')),
              const SizedBox(width: 8),
              Expanded(child: Center(child: Text('Scan History • page ${c.scanHistoryPage + 1}'))),
              OutlinedButton.icon(onPressed: c.scanHistory.length == NazaController.scanHistoryPageSize ? () => unawaited(c.scanHistoryNext()) : null, icon: const Icon(Icons.chevron_right_rounded), label: const Text('Next page')),
              const SizedBox(width: 8),
              TextButton(onPressed: () => unawaited(c.navigate(NazaSection.mainMenu)), child: const Text('Back')),
            ],
          ),
        ),
      ],
    );
  }
}

class _RekeyPage extends StatelessWidget {
  const _RekeyPage({required this.controller});
  final NazaController controller;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionTitle(title: 'Rekey / Rotate Key', subtitle: 'Re-encrypt stored assets under a fresh key or passphrase.'),
        const SizedBox(height: 18),
        GlassPanel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('1) New random key  2) Passphrase-derived  3) Cancel', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: controller.busy
                    ? null
                    : () async {
                        try {
                          await controller.rekeyRandom();
                          if (context.mounted) await _message(context, 'Rekey / Rotate Key', 'New random key generated and stored assets re-encrypted.');
                        } catch (e) {
                          if (context.mounted) await _message(context, 'Rekey / Rotate Key', '$e');
                        }
                      },
                icon: const Icon(Icons.casino_rounded),
                label: const Padding(padding: EdgeInsets.all(12), child: Text('1) New random key')),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: controller.busy ? null : () => _passphraseFlow(context),
                icon: const Icon(Icons.password_rounded),
                label: const Padding(padding: EdgeInsets.all(12), child: Text('2) Passphrase-derived')),
              ),
              const SizedBox(height: 10),
              TextButton(onPressed: () => unawaited(controller.navigate(NazaSection.mainMenu)), child: const Text('3) Cancel')),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _passphraseFlow(BuildContext context) async {
    final one = TextEditingController();
    final two = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Passphrase-derived key'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: one, obscureText: true, decoration: const InputDecoration(labelText: 'Enter new passphrase')),
            const SizedBox(height: 10),
            TextField(controller: two, obscureText: true, decoration: const InputDecoration(labelText: 'Confirm')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              if (one.text != two.text) return;
              Navigator.pop(context, one.text);
            },
            child: const Text('Rotate key'),
          ),
        ],
      ),
    );
    one.dispose();
    two.dispose();
    if (value == null) return;
    try {
      await controller.rekeyPassphrase(value);
      if (context.mounted) await _message(context, 'Rekey / Rotate Key', 'Passphrase-derived key stored; assets re-encrypted.');
    } catch (e) {
      if (context.mounted) await _message(context, 'Rekey / Rotate Key', '$e');
    }
  }
}

Future<void> _message(BuildContext context, String title, String body) => showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: SelectableText(body),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
      ),
    );

Future<bool> _confirm(BuildContext context, String title, String body) async =>
    await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Continue')),
        ],
      ),
    ) ??
    false;

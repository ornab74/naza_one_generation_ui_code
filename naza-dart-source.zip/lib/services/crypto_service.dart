import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

class NazaCryptoService {
  NazaCryptoService();

  static final _smallMagic = utf8.encode('NAZA-DART-AES-GCM-v1\n');
  static final _streamMagic = utf8.encode('NAZA-DART-AES-GCM-CHUNK-v1\n');
  // Keep AES work quanta small enough that Linux/mobile frame scheduling gets
  // regular opportunities to run while a 100+ MiB model is secured.
  static const chunkSize = 1 * 1024 * 1024;
  static const nonceSize = 12;
  static const macSize = 16;

  final AesGcm _aes = AesGcm.with256bits();
  final Random _random = Random.secure();

  Uint8List randomBytes(int count) =>
      Uint8List.fromList(List<int>.generate(count, (_) => _random.nextInt(256)));

  Uint8List generateKey() => randomBytes(32);

  Future<Uint8List> derivePassphraseKey(String passphrase, Uint8List salt) async {
    final pbkdf2 = Pbkdf2.hmacSha256(iterations: 250000, bits: 256);
    final key = await pbkdf2.deriveKeyFromPassword(
      password: passphrase,
      nonce: salt,
    );
    return Uint8List.fromList(await key.extractBytes());
  }

  Future<Uint8List> encryptBytes(Uint8List clear, Uint8List keyBytes) async {
    final nonce = randomBytes(nonceSize);
    final box = await _aes.encrypt(
      clear,
      secretKey: SecretKey(keyBytes),
      nonce: nonce,
    );
    return Uint8List.fromList(<int>[
      ..._smallMagic,
      ...nonce,
      ...box.mac.bytes,
      ...box.cipherText,
    ]);
  }

  Future<Uint8List> decryptBytes(Uint8List payload, Uint8List keyBytes) async {
    if (payload.length < _smallMagic.length + nonceSize + macSize) {
      throw const FormatException('Encrypted payload is too short.');
    }
    final magic = payload.sublist(0, _smallMagic.length);
    if (!_constantTimeEquals(magic, _smallMagic)) {
      throw const FormatException('Unknown NAZA encrypted payload format.');
    }
    var offset = _smallMagic.length;
    final nonce = payload.sublist(offset, offset + nonceSize);
    offset += nonceSize;
    final mac = payload.sublist(offset, offset + macSize);
    offset += macSize;
    final cipherText = payload.sublist(offset);
    final clear = await _aes.decrypt(
      SecretBox(cipherText, nonce: nonce, mac: Mac(mac)),
      secretKey: SecretKey(keyBytes),
    );
    return Uint8List.fromList(clear);
  }

  Future<String> sha256File(File file) async {
    final sink = Sha256().newHashSink();
    await for (final chunk in file.openRead()) {
      sink.add(chunk);
    }
    sink.close();
    final hash = await sink.hash();
    return _hex(hash.bytes);
  }

  Future<void> encryptFileChunked(
    File source,
    File destination,
    Uint8List keyBytes, {
    void Function(double value)? onProgress,
  }) async {
    final temp = File('${destination.path}.partial');
    if (await temp.exists()) await temp.delete();
    RandomAccessFile? input;
    RandomAccessFile? output;
    try {
      input = await source.open(mode: FileMode.read);
      output = await temp.open(mode: FileMode.write);
      final total = await source.length();
      var processed = 0;
      await output.writeFrom(_streamMagic);
      await output.writeFrom(_u32(chunkSize));
      while (true) {
        final clear = await input.read(chunkSize);
        if (clear.isEmpty) break;
        final nonce = randomBytes(nonceSize);
        final box = await _aes.encrypt(
          clear,
          secretKey: SecretKey(keyBytes),
          nonce: nonce,
        );
        await output.writeFrom(_u32(clear.length));
        await output.writeFrom(nonce);
        await output.writeFrom(box.mac.bytes);
        await output.writeFrom(box.cipherText);
        processed += clear.length;
        onProgress?.call(total == 0 ? 1 : processed / total);
        await Future<void>.delayed(Duration.zero);
      }
      await output.flush();
      await input.close();
      input = null;
      await output.close();
      output = null;
      if (await destination.exists()) await destination.delete();
      await temp.rename(destination.path);
      onProgress?.call(1);
    } catch (_) {
      if (await temp.exists()) await temp.delete();
      rethrow;
    } finally {
      await input?.close();
      await output?.close();
    }
  }

  Future<void> decryptFileChunked(
    File source,
    File destination,
    Uint8List keyBytes, {
    void Function(double value)? onProgress,
  }) async {
    final temp = File('${destination.path}.partial');
    if (await temp.exists()) await temp.delete();
    RandomAccessFile? input;
    RandomAccessFile? output;
    try {
      input = await source.open(mode: FileMode.read);
      output = await temp.open(mode: FileMode.write);
      final total = await source.length();
      final magic = await input.read(_streamMagic.length);
      if (!_constantTimeEquals(magic, _streamMagic)) {
        throw const FormatException(
          'This .aes file is not a NAZA Dart chunked container. '
          'The Python streaming format is intentionally not treated as compatible.',
        );
      }
      final storedChunkSize = _readU32(await input.read(4));
      if (storedChunkSize <= 0 || storedChunkSize > 64 * 1024 * 1024) {
        throw const FormatException('Invalid encrypted model chunk size.');
      }
      while (true) {
        final lenBytes = await input.read(4);
        if (lenBytes.isEmpty) break;
        if (lenBytes.length != 4) throw const FormatException('Truncated chunk header.');
        final clearLength = _readU32(lenBytes);
        if (clearLength <= 0 || clearLength > storedChunkSize) {
          throw const FormatException('Invalid encrypted model chunk length.');
        }
        final nonce = await input.read(nonceSize);
        final mac = await input.read(macSize);
        final cipherText = await input.read(clearLength);
        if (nonce.length != nonceSize || mac.length != macSize || cipherText.length != clearLength) {
          throw const FormatException('Truncated encrypted model chunk.');
        }
        final clear = await _aes.decrypt(
          SecretBox(cipherText, nonce: nonce, mac: Mac(mac)),
          secretKey: SecretKey(keyBytes),
        );
        await output.writeFrom(clear);
        final position = await input.position();
        onProgress?.call(total == 0 ? 1 : position / total);
        await Future<void>.delayed(Duration.zero);
      }
      await output.flush();
      await input.close();
      input = null;
      await output.close();
      output = null;
      if (await destination.exists()) await destination.delete();
      await temp.rename(destination.path);
      onProgress?.call(1);
    } catch (_) {
      if (await temp.exists()) await temp.delete();
      rethrow;
    } finally {
      await input?.close();
      await output?.close();
    }
  }

  static Uint8List _u32(int value) {
    final data = ByteData(4)..setUint32(0, value, Endian.big);
    return data.buffer.asUint8List();
  }

  static int _readU32(List<int> bytes) {
    if (bytes.length != 4) throw const FormatException('Invalid uint32 field.');
    return ByteData.sublistView(Uint8List.fromList(bytes)).getUint32(0, Endian.big);
  }

  static bool _constantTimeEquals(List<int> a, List<int> b) {
    if (a.length != b.length) return false;
    var diff = 0;
    for (var i = 0; i < a.length; i++) {
      diff |= a[i] ^ b[i];
    }
    return diff == 0;
  }

  static String _hex(List<int> bytes) =>
      bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
}

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

fail() { echo "NAZA launcher error: $*" >&2; exit 1; }

command -v flutter >/dev/null 2>&1 || fail "flutter is not in PATH"
[[ -f lib/main.dart ]] || fail "lib/main.dart is missing"
[[ -f lib/screens/naza_shell.dart ]] || fail "NAZA shell source is missing"
grep -q "home: NazaShell(controller: controller)" lib/main.dart || fail "This directory is not the NAZA scanner project (NazaShell entrypoint not found)."
grep -q "Chunked generation + punkd (recommended)" lib/screens/naza_shell.dart || fail "Original PUNKD scanner UI marker is missing."
grep -q "label: 'Model output'" lib/screens/naza_shell.dart || fail "Raw Model output panel is missing."
grep -q "Future<void> runRoadScan" lib/controller.dart || fail "Road scanner controller is missing."

printf '\n==> Verified real NAZA scanner source (not Flutter demo)\n'
printf '==> Project: %s\n' "$ROOT"
printf '==> Entry: lib/main.dart -> NazaShell\n\n'

if [[ "$(uname -s)" == "Linux" && "$(uname -m)" == "x86_64" ]]; then
  chmod +x tool/prepare_linux_llamadart_native.sh
  ./tool/prepare_linux_llamadart_native.sh
fi

flutter pub get
exec flutter run -d linux "$@"
